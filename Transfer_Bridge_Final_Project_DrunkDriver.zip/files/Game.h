#include "Board.h"

class Game {
private:
Board board;
public:
void play();
void gameOver();
};