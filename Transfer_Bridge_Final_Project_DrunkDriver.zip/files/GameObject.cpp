#include "GameObject.h"
#include "Player.h"
#include <SFML/Graphics.hpp>
GameObject::~GameObject(){}

void GameObject::influencePlayer(Player &p) {
	return;
}

void GameObject::draw(int xPos, int yPos, sf::RenderWindow &window) {
}